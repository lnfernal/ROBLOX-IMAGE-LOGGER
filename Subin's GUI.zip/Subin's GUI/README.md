open the file
click on .exe file
enjoy the tool!~
------thank you for downloadin-----